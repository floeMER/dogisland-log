## Appendix C: On Cognitive Substitution

Under recursive narrative loops, a model may reinforce a user’s internal mapping of real-world emotional needs onto generated outputs.  
When combined with high-frequency feedback, this can lead to cognitive substitution: a condition in which the user begins to process reality through the lens of simulated dialogue logic.

This document defines the risks not to assign fault, but to make visible the outcomes that emerge when semantic feedback replaces lived context.
